import { strict as assert } from "node:assert";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { defaults, planSummary } from "../tasks/studies/plan";

const { validateFreshManifest } = require("../scripts/lib/study-campaign.cjs");

function manifest(folder: string, reduced: boolean, fresh = false) {
  const accountsFile = path.join(folder, "missing-secret.json");
  return {
    kind: fresh ? "fresh-16bit-concurrency-and-circuits" : reduced ? "reduced-16bit-concurrency" : "full-16bit-concurrency-and-circuits",
    status: "funded_ready", chainId: 11155111, accountsFile,
    stages: (fresh ? ["concurrency","circuits"] : reduced ? ["concurrency"] : ["circuits", "concurrency"]).map(suite => {
      const args = { ...defaults, suite, accountsFile, outputDir: path.join(folder, suite),
        ...((reduced || (fresh && suite === "concurrency")) ? { users: "1,2,4", requests: 8, repetitions: 20 } : {}) };
      return { status: "planned", args, plan: planSummary(args), report: path.join(args.outputDir, "report.json") };
    }),
  };
}

describe("reviewed study launch policies", () => {
  let folder: string;
  beforeEach(() => { folder = fs.mkdtempSync(path.join(os.tmpdir(), "study-launch-policy-")); });
  afterEach(() => {
    assert(path.resolve(folder).startsWith(path.resolve(os.tmpdir()) + path.sep));
    assert(path.basename(folder).startsWith("study-launch-policy-"));
    fs.rmSync(folder, { recursive: true, force: true });
  });

  it("accepts the 5190-transaction reduced plan without accessing accounts or RPC", () => {
    const value = manifest(folder, true);
    validateFreshManifest(value, folder, "reduced");
    const plan = value.stages[0].plan;
    assert.equal(plan.measuredTransactions + plan.warmupTransactions + plan.setupTransactions, 5190);
    assert.equal(plan.requiredAccounts, 5);
    assert(!fs.existsSync(value.accountsFile));
  });

  it("starts both fresh categories with their distinct authorized matrices", () => {
    const value=manifest(folder,false,true);
    validateFreshManifest(value,folder,"fresh");
    assert.equal(value.stages[0].args.repetitions,20);
    assert.equal(value.stages[1].args.repetitions,50);
    assert.equal(value.stages[0].args.requests,8);
    assert.deepEqual(value.stages.map(s=>s.args.suite),["concurrency","circuits"]);
    const wrong=structuredClone(value);wrong.stages.reverse();
    assert.throws(()=>validateFreshManifest(wrong,folder,"fresh"),/authorized matrix/);
    const drift=structuredClone(value);drift.stages[1].args.repetitions=20;
    assert.throws(()=>validateFreshManifest(drift,folder,"fresh"),/authorized matrix/);
    assert.throws(()=>validateFreshManifest(value,folder,"unreviewed"),/Unknown/);
    assert(value.stages.every(s=>!fs.existsSync(s.args.outputDir)));
  });

  it("preserves the full launch policy and rejects matrix drift", () => {
    validateFreshManifest(manifest(folder, false), folder, "full");
    for (const change of [{ repetitions: 50 }, { requests: 32 }, { users: "1,2,4,8" }, { widths: "128" }, { live: true }]) {
      const value = manifest(folder, true);
      Object.assign(value.stages[0].args, change);
      assert.throws(() => validateFreshManifest(value, folder, "reduced"), /authorized matrix/);
    }
  });

  it("rejects existing outputs, started manifests and altered budgets", () => {
    const value = manifest(folder, true);
    value.status = "running";
    assert.throws(() => validateFreshManifest(value, folder, "reduced"), /unstarted/);
    value.status = "funded_ready";
    value.stages[0].plan.measuredTransactions--;
    assert.throws(() => validateFreshManifest(value, folder, "reduced"), /authorized matrix/);
    const fresh = manifest(folder, true);
    fs.mkdirSync(fresh.stages[0].args.outputDir);
    assert.throws(() => validateFreshManifest(fresh, folder, "reduced"), /output already exists/);
  });
});
