# Circuiti128: pilot descrittivo segmentato

Tutti gli81 tentativi misurati pianificati sono risolti:78 compute validate e3 rifiuti senza invio. Warmup:26 validati e1 rifiuto senza invio. Zama affine_chain k4 produce HCUTransactionDepthLimitExceeded in tutti e quattro i tentativi, compreso il warmup. Il limite osservato non è un revert on-chain e non riceve gas/latenza zero.

Il fallimento di preparazione RPC header for hash not found è conservato. La continuazione ha riusato un caricamento già confermato e aggiunto24 compute valide;54 erano già valide nel segmento iniziale. Nessun deployment/warmup è stato ripetuto.

| Caso | Piattaforma | Compute valide / limiti | Receipt ms (n) | Plaintext validato ms (n) | Gas compute |
|---|---|---:|---:|---:|---:|
| circuits-w128-sum_linear-n2 | baseline | 3 / 0 | 10886.8 (3) | 11057.6 (3) | 465333.0 (3) |
| circuits-w128-sum_linear-n2 | zama | 3 / 0 | 6991.7 (3) | 11079.7 (3) | 761558.0 (3) |
| circuits-w128-sum_linear-n2 | fhenix | 3 / 0 | 10004.0 (3) | 11024.2 (3) | 751676.0 (3) |
| circuits-w128-sum_tree-n2 | baseline | 3 / 0 | 15334.1 (3) | 15456.1 (3) | 465674.0 (3) |
| circuits-w128-sum_tree-n2 | zama | 3 / 0 | 10951.7 (3) | 14641.2 (3) | 762322.0 (3) |
| circuits-w128-sum_tree-n2 | fhenix | 3 / 0 | 15590.7 (3) | 15885.4 (3) | 752440.0 (3) |
| circuits-w128-sum_linear-n4 | baseline | 3 / 0 | 14527.0 (3) | 14634.8 (3) | 468157.0 (3) |
| circuits-w128-sum_linear-n4 | zama | 3 / 0 | 5309.2 (3) | 10430.1 (3) | 802024.7 (3) |
| circuits-w128-sum_linear-n4 | fhenix | 3 / 0 | 14844.0 (3) | 15497.7 (3) | 815494.0 (3) |
| circuits-w128-sum_tree-n4 | baseline | 3 / 0 | 10771.3 (3) | 11248.0 (3) | 468892.0 (3) |
| circuits-w128-sum_tree-n4 | zama | 3 / 0 | 7162.7 (3) | 11993.3 (3) | 803888.0 (3) |
| circuits-w128-sum_tree-n4 | fhenix | 3 / 0 | 11550.5 (3) | 12586.2 (3) | 817364.0 (3) |
| circuits-w128-sum_linear-n8 | baseline | 3 / 0 | 15418.6 (3) | 15537.9 (3) | 473809.0 (3) |
| circuits-w128-sum_linear-n8 | zama | 3 / 0 | 8821.2 (3) | 15667.4 (3) | 882963.0 (3) |
| circuits-w128-sum_linear-n8 | fhenix | 3 / 0 | 14373.1 (3) | 16498.5 (3) | 943154.0 (3) |
| circuits-w128-sum_tree-n8 | baseline | 3 / 0 | 10651.8 (3) | 10792.0 (3) | 475238.0 (3) |
| circuits-w128-sum_tree-n8 | zama | 3 / 0 | 4569.9 (3) | 10442.7 (3) | 886763.7 (3) |
| circuits-w128-sum_tree-n8 | fhenix | 3 / 0 | 10395.4 (3) | 11782.8 (3) | 946956.0 (3) |
| circuits-w128-affine_chain-k1 | baseline | 3 / 0 | 14983.9 (3) | 15457.9 (3) | 465407.0 (3) |
| circuits-w128-affine_chain-k1 | zama | 3 / 0 | 10778.8 (3) | 18749.6 (3) | 777557.7 (3) |
| circuits-w128-affine_chain-k1 | fhenix | 3 / 0 | 10588.4 (3) | 13539.5 (3) | 780386.0 (3) |
| circuits-w128-affine_chain-k2 | baseline | 3 / 0 | 8927.1 (3) | 9073.1 (3) | 465583.0 (3) |
| circuits-w128-affine_chain-k2 | zama | 3 / 0 | 11114.9 (3) | 22608.0 (3) | 809635.0 (3) |
| circuits-w128-affine_chain-k2 | fhenix | 3 / 0 | 8422.9 (3) | 14010.2 (3) | 836837.0 (3) |
| circuits-w128-affine_chain-k4 | baseline | 3 / 0 | 19495.0 (3) | 19622.9 (3) | 465931.0 (3) |
| circuits-w128-affine_chain-k4 | zama | 0 / 3 | -- | -- | -- |
| circuits-w128-affine_chain-k4 | fhenix | 3 / 0 | 10520.7 (3) | 20644.0 (3) | 949752.0 (3) |

Costo registrato di218 receipt, inclusi deployment/autorizzazioni/input/warmup: 3889423955wei (0.000000003889423955ETH). Riverifica RPC finale dopo le prove live.

La preparazione fresca include caricamenti e attesa di disponibilità degli input. Il lavoro client completo è preparazione+compute-to-plaintext; la preparazione ripresa è separata e ha un perimetro ridotto. Nessuna metrica rappresenta il puro tempo di calcolo FHE. Tre ripetizioni sono un pilot, non una stima robusta o causale. I dati16bit e quelli classici rimangono separati.

SHA256 del report grezzo: 1046dc71347a0708ace1c2a50d57be7628e9997254c039e5cccfc282a297edf9.
