# Concorrenza16: pilot descrittivo segmentato

Tutte le operazioni pianificate sono state eseguite.424/432 richieste misurate verificate durante lâ€™audit originale;8/432 verificate con audit tardivo separato. Controlli:200 originali + 16 tardivi=216. Il report mantiene `complete=false` e conserva una preparazione fallita e tre audit interrotti.

27/53 finestre misurate con audit originale hanno ordine diverso da quello pianificato;9/53 hanno un risultato finale diverso da quello dellâ€™ordine pianificato. Nessuna delle54 finestre verificate (53 originali + 1 tardiva) ha mostrato una discrepanza rispetto al replay canonico. I controlli forward/reverse confermano risultati uguali per somma/independent e diversi per shared_ordered, come previsto.

| Caso | Piattaforma | Finestre originali + tardive | Receipt ms (n) | Audit differito ms (n) | Gas medio |
|---|---|---:|---:|---:|---:|
| concurrency-w16-c1-independent | baseline | 3 + 0 | 11374.6 (24) | 115.1 (24) | 407653.0 |
| concurrency-w16-c1-independent | zama | 2 + 1 | 14929.8 (23) | 2503.4 (16) | 989680.7 |
| concurrency-w16-c1-independent | fhenix | 3 + 0 | 12742.0 (24) | 202.9 (24) | 813325.0 |
| concurrency-w16-c1-shared_sum | baseline | 3 + 0 | 15026.1 (24) | 75.9 (24) | 407394.5 |
| concurrency-w16-c1-shared_sum | zama | 3 + 0 | 14537.1 (24) | 2481.3 (24) | 989413.8 |
| concurrency-w16-c1-shared_sum | fhenix | 3 + 0 | 13794.1 (24) | 166.6 (24) | 813069.0 |
| concurrency-w16-c1-shared_ordered | baseline | 3 + 0 | 15675.6 (24) | 144.6 (24) | 395342.5 |
| concurrency-w16-c1-shared_ordered | zama | 3 + 0 | 12119.4 (24) | 2604.0 (24) | 1009304.8 |
| concurrency-w16-c1-shared_ordered | fhenix | 3 + 0 | 12146.9 (24) | 203.5 (24) | 845737.0 |
| concurrency-w16-c2-independent | baseline | 3 + 0 | 14786.3 (24) | 91.6 (24) | 419896.5 |
| concurrency-w16-c2-independent | zama | 3 + 0 | 10257.1 (24) | 2450.3 (24) | 989677.2 |
| concurrency-w16-c2-independent | fhenix | 3 + 0 | 17849.2 (24) | 198.3 (24) | 813325.0 |
| concurrency-w16-c2-shared_sum | baseline | 3 + 0 | 12965.7 (24) | 122.6 (24) | 407396.5 |
| concurrency-w16-c2-shared_sum | zama | 3 + 0 | 11274.3 (24) | 2548.0 (24) | 989414.3 |
| concurrency-w16-c2-shared_sum | fhenix | 3 + 0 | 14512.8 (24) | 226.5 (24) | 813070.5 |
| concurrency-w16-c2-shared_ordered | baseline | 3 + 0 | 17431.4 (24) | 104.6 (24) | 395347.0 |
| concurrency-w16-c2-shared_ordered | zama | 3 + 0 | 12140.0 (24) | 2635.1 (24) | 1009297.5 |
| concurrency-w16-c2-shared_ordered | fhenix | 3 + 0 | 12801.9 (24) | 176.2 (24) | 845733.0 |

Costo registrato, con receipt canonica supplementare per la reinclusione, inclusi deployment/autorizzazioni/setup/controlli: 10602020178wei = 0.000000010602020178ETH. La riverifica RPC finale di tutte le receipt sarÃ  svolta dopo le prove live.

Le durate degli audit differiti sono letture/decryption di risultati giÃ  pronti; non misurano il tempo di completamento FHE. Le piattaforme hanno finestre separate e ordine ruotato. La latenza della receipt reinclusa Ã¨ esclusa; quella della reinclusione non Ã¨ ricostruita. Nessun p-value o affermazione causale. Tre finestre per configurazione sono una verifica pilota, non una garanzia di robustezza.

Report grezzo SHA256: 215315ec2df02dd93ce3e1e0ec395d36c209e409e6c95a13f4f0fc3cec3b3e05.
