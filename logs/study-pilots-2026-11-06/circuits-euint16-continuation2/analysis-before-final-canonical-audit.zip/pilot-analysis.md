# Pilot circuiti euint16: analisi descrittiva segmentata

81/81 compute misurate e 27/27 warmup validi; due preparazioni fallite senza invio compute sono conservate. Il flag raw complete resta false.
Ogni cella contiene tre successi. Nessun test inferenziale o confronto causale. Gli SDK e i timer primari sono invariati; le interruzioni e le modifiche alla preparazione sono documentate.

| Caso | Piattaforma | n | Gas medio | Tx-receipt ms | Tx-plaintext validato ms | Post-receipt ms |
|---|---|---:|---:|---:|---:|---:|
| circuits-w16-affine_chain-k1 | baseline | 3 | 465353.0 | 8609.1 | 8718.0 | 108.9 |
| circuits-w16-affine_chain-k1 | fhenix | 3 | 780214.0 | 10491.9 | 11256.0 | 764.2 |
| circuits-w16-affine_chain-k1 | zama | 3 | 777263.7 | 4866.3 | 9611.8 | 4745.6 |
| circuits-w16-affine_chain-k2 | baseline | 3 | 465533.0 | 14208.7 | 14325.5 | 116.8 |
| circuits-w16-affine_chain-k2 | fhenix | 3 | 836521.0 | 9056.2 | 10081.1 | 1024.9 |
| circuits-w16-affine_chain-k2 | zama | 3 | 809043.0 | 7931.6 | 12167.6 | 4236.0 |
| circuits-w16-affine_chain-k4 | baseline | 3 | 465885.0 | 18184.1 | 18664.7 | 480.6 |
| circuits-w16-affine_chain-k4 | fhenix | 3 | 949116.0 | 12570.4 | 13546.1 | 975.7 |
| circuits-w16-affine_chain-k4 | zama | 3 | 872601.7 | 6551.8 | 12374.2 | 5822.4 |
| circuits-w16-sum_linear-n2 | baseline | 3 | 465283.0 | 9373.1 | 9500.5 | 127.4 |
| circuits-w16-sum_linear-n2 | fhenix | 3 | 751590.0 | 10414.9 | 12135.4 | 1720.5 |
| circuits-w16-sum_linear-n2 | zama | 3 | 761411.0 | 6274.5 | 9726.3 | 3451.8 |
| circuits-w16-sum_linear-n4 | baseline | 3 | 466113.0 | 10287.7 | 10785.0 | 497.2 |
| circuits-w16-sum_linear-n4 | fhenix | 3 | 815268.0 | 10591.6 | 17081.3 | 6489.7 |
| circuits-w16-sum_linear-n4 | zama | 3 | 801583.7 | 6788.3 | 13323.5 | 6535.2 |
| circuits-w16-sum_linear-n8 | baseline | 3 | 467761.0 | 15000.1 | 15490.7 | 490.6 |
| circuits-w16-sum_linear-n8 | fhenix | 3 | 942600.0 | 9870.8 | 10861.4 | 990.6 |
| circuits-w16-sum_linear-n8 | zama | 3 | 881928.7 | 10227.1 | 13719.5 | 3492.5 |
| circuits-w16-sum_tree-n2 | baseline | 3 | 465616.0 | 9912.3 | 10416.2 | 503.9 |
| circuits-w16-sum_tree-n2 | fhenix | 3 | 752354.0 | 9040.0 | 9748.1 | 708.1 |
| circuits-w16-sum_tree-n2 | zama | 3 | 762169.7 | 9647.5 | 14239.3 | 4591.9 |
| circuits-w16-sum_tree-n4 | baseline | 3 | 466808.0 | 13634.7 | 13750.4 | 115.8 |
| circuits-w16-sum_tree-n4 | fhenix | 3 | 817126.0 | 8135.8 | 8435.5 | 299.8 |
| circuits-w16-sum_tree-n4 | zama | 3 | 803441.7 | 12046.0 | 17623.9 | 5577.9 |
| circuits-w16-sum_tree-n8 | baseline | 3 | 469102.0 | 16061.7 | 16190.3 | 128.6 |
| circuits-w16-sum_tree-n8 | fhenix | 3 | 946410.0 | 24326.5 | 25709.0 | 1382.5 |
| circuits-w16-sum_tree-n8 | zama | 3 | 885734.7 | 6679.1 | 11816.3 | 5137.3 |

Costo effettivo delle 222 receipt, incluse deployment, autorizzazioni, caricamenti input e warmup: 4.466025756E-9 ETH Sepolia.
Finanziamento degli account escluso e registrato separatamente. Le preparazioni riprese sono escluse dalla media di preparazione fresca (denominatori nel CSV/JSON).
La latenza include inclusione, getter, SDK, polling, decrypt e validazione; non misura FHE compute isolata. SHA256, prefissi, oracolo aritmetico, timer e costi gas sono verificati in completion-audit.json.
