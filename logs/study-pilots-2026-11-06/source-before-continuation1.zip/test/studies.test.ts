import { strict as assert } from "node:assert";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import hre from "hardhat";
import { defaults, buildPlan, expectedCircuit, planSummary } from "../tasks/studies/plan";
import { replay, zeroFailureUpper95 } from "../tasks/studies/oracle";
import { capacityRejection } from "../tasks/studies/capacity";
import { runStudy } from "../tasks/studies/runner";
import type { StudyReport } from "../tasks/studies/report";

describe("focused study planning and canonical oracle", () => {
  it("contains only the two studies, equal-work reduction pairs and explicit transaction budgets", () => {
    const plan = planSummary(defaults);
    assert.equal(plan.cases.filter(c => c.suite === "concurrency").length,24);
    assert.equal(plan.cases.filter(c => c.suite === "circuits").length,32);
    assert.equal(plan.measuredTransactions,120000);
    assert.equal(plan.warmupTransactions,2976);
    assert.equal(plan.setupTransactions,8904);
    assert.equal(plan.requiredAccounts,9);
    for (const width of [16,128]) for (const n of [2,4,8,16,32]) {
      const pair = plan.cases.filter(c => c.width === width && c.inputCount === n && c.circuit?.startsWith("sum_"));
      assert.deepEqual(pair.map(c => c.additions),[n-1,n-1]);
      assert.deepEqual(pair.map(c => c.dependencyDepth),[n-1,Math.log2(n)]);
    }
    assert.throws(() => buildPlan({...defaults,suite:"state"}),/Only concurrency/);
    assert.throws(() => buildPlan({...defaults,requests:10}),/divisible/);
    assert.throws(() => buildPlan({...defaults,widths:"64"}),/Widths/);
    assert.equal(capacityRejection({info:{error:{data:hre.ethers.id("HCUTransactionLimitExceeded()").slice(0,10)}}}),"HCUTransactionLimitExceeded");
    assert.equal(capacityRejection(new Error("Timeout, out of gas or arbitrary revert")),undefined);
  });

  it("does not touch providers, accounts or directories in default planning mode", async () => {
    const plan: any = await runStudy({...defaults,accountsFile:"missing-secret-file"},{} as any);
    assert.equal(plan.networkAccess,false);
  });

  it("treats valid order-dependent outputs as expected and rejects duplicate/missing canonical evidence", () => {
    const inputs = [{requestId:"a",user:"alice",value:2n,blockNumber:10,transactionIndex:1,sequence:2},
      {requestId:"b",user:"bob",value:7n,blockNumber:10,transactionIndex:0,sequence:1}];
    assert.equal(replay(inputs,"shared_ordered",16).state.shared,23n);
    const forward = inputs.map((r,i) => ({...r,transactionIndex:i,sequence:i+1}));
    assert.equal(replay(forward,"shared_ordered",16).state.shared,13n);
    assert.equal(replay(inputs,"shared_sum",16).state.shared,9n);
    assert.equal(replay(forward,"shared_sum",16).state.shared,9n);
    assert.throws(() => replay([inputs[0],inputs[0]],"shared_sum",16),/Duplicate request/);
    assert.throws(() => replay(inputs.map(r => ({...r,transactionIndex:0})),"shared_sum",16),/Duplicate canonical/);
    assert.throws(() => replay(inputs.map(r => ({...r,sequence:1})),"shared_sum",16),/sequence/);
    assert.throws(() => replay([{...inputs[0],transactionIndex:NaN}],"shared_sum",16),/Missing canonical/);
  });

  it("checks 10,000 valid sender-order-preserving permutations without confusing commutativity with races", () => {
    let seed=17, changed=0;
    const random=() => {seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};
    for (let trial=0;trial<10000;trial++) {
      const queues=Array.from({length:4},(_,u) => Array.from({length:8},(_,i) => ({
        requestId:`${u}/${i}`,user:`user${u}`,value:BigInt(u*19+i*7+1),blockNumber:1,transactionIndex:0})));
      const all=queues.flat(), canonical=[];
      while (canonical.length<32) {
        const nonempty=queues.filter(q => q.length), q=nonempty[Math.floor(random()*nonempty.length)];
        canonical.push({...q.shift()!,transactionIndex:canonical.length});
      }
      const sum=all.reduce((n,r)=>n+r.value,0n);
      assert.equal(replay(canonical,"shared_sum",16).state.shared,BigInt.asUintN(16,sum));
      const independent=replay(canonical,"independent",16).state;
      for (let u=0;u<4;u++) assert.equal(independent[`user${u}`],all.filter(r=>r.user===`user${u}`).reduce((n,r)=>n+r.value,0n));
      const forward=all.map((r,i)=>({...r,transactionIndex:i}));
      if(replay(canonical,"shared_ordered",16).state.shared!==replay(forward,"shared_ordered",16).state.shared)changed++;
    }
    assert(changed>9000);
  });

  it("uses full-width modular arithmetic and labels robustness at the window level", () => {
    const c=buildPlan({...defaults,suite:"circuits",widths:"128",sizes:"2",depths:"2"});
    const values=[(1n<<128n)-1n,3n];
    assert.equal(expectedCircuit(c[0],values),2n);
    assert.equal(expectedCircuit(c[1],values),2n);
    assert.equal(expectedCircuit(c[2],values),(1n<<128n)-13n);
    assert(Math.abs(zeroFailureUpper95(50)-0.0581550791)<1e-9);
    assert(zeroFailureUpper95(300)<0.01);
  });
});

describe("local study integration (not public-network performance)", function () {
  this.timeout(180000);
  it("runs both studies on baseline and mock Zama with stable snapshots, controls, unique nonces and preserved classics", async () => {
    const parent=fs.mkdtempSync(path.join(os.tmpdir(),"focused-studies-")), output=path.join(parent,"run");
    try {
      const args={...defaults,platform:"baseline,zama",widths:"16",users:"1,2",sizes:"2,4",depths:"1,2",
        requests:4,repetitions:1,live:true,outputDir:output};
      const report=await runStudy(args,hre) as StudyReport;
      assert(report.complete,report.error);
      assert(report.trials.every(t=>t.status==="ok"));
      const controls=JSON.parse(fs.readFileSync(path.join(output,"controls.json"),"utf8"));
      assert(controls.every((c:any)=>c.complete&&c.sameObservedFinal===c.expectedSameFinal));
      assert.equal(controls.length,6);
      const transactions=[...report.setups.map(s=>s.transaction),...report.trials.flatMap(t=>[...t.setup,...t.requests.map(r=>r.transaction)])];
      for(const user of report.accounts){
        const nonces=transactions.filter(t=>t.user===user).map(t=>t.transactionNonce).sort((a,b)=>a-b);
        assert.equal(nonces.length,new Set(nonces).size);
        assert(nonces.every((n,i)=>n===nonces[0]+i));
      }
      assert(report.trials.filter(t=>!t.warmup&&t.requests.length===4).every(t=>t.requests.every(r=>r.auditCallMs!==undefined&&r.transactionToValidatedMs===undefined)));
      for (const trial of report.trials.filter(t=>t.requests.length===1)) {
        const r=trial.requests[0];
        assert(Math.abs(r.transaction.receiptMs!+r.postReceiptMs!-r.transactionToValidatedMs!)<0.0001);
      }
      const before=fs.readFileSync(path.join(output,"report.json"),"utf8");
      assert(!before.includes("privateKey")&&!before.includes('"raw"'));
      await assert.rejects(runStudy(args,hre),/fresh output/);
      assert.equal(fs.readFileSync(path.join(output,"report.json"),"utf8"),before);
    } finally {
      for(const name of ["report.json","summary.json","summary.md","controls.json","costs.json","transactions.jsonl"]){
        const f=path.join(output,name);if(fs.existsSync(f))fs.unlinkSync(f);
      }
      if(fs.existsSync(output))fs.rmdirSync(output);fs.rmdirSync(parent);
    }
  });

  it("records rejected circuits without fake gas/latency, and continues with contiguous nonces", async () => {
    const parent=fs.mkdtempSync(path.join(os.tmpdir(),"study-capacity-")),output=path.join(parent,"run");
    try {
      const report=await runStudy({...defaults,suite:"circuits",platform:"zama",widths:"128",sizes:"2,32",
        depths:"2,32",repetitions:1,live:true,outputDir:output},hre) as StudyReport;
      assert(report.executionComplete);
      assert.equal(report.complete,false);
      assert(report.trials.some(t=>t.status==="ok"));
      const rejected=report.trials.filter(t=>t.status==="capacity_rejected");
      assert(rejected.length>=4); // Warmup and measured depth/linear boundaries.
      for(const t of rejected) {
        const r=t.requests[0];
        assert.equal(t.rejection?.broadcast,false);
        assert.equal(r.transaction.transactionNonce,-1);
        assert.equal(r.transaction.transactionHash,undefined);
        assert.equal(r.transaction.gasUsed,undefined);
        assert.equal(r.transactionToValidatedMs,undefined);
      }
      const txs=[...report.setups.map(s=>s.transaction),...report.trials.flatMap(t=>[...t.setup,...t.requests.map(r=>r.transaction)])];
      const nonces=txs.filter(t=>t.transactionNonce>=0).map(t=>t.transactionNonce).sort((a,b)=>a-b);
      assert(nonces.every((n,i)=>n===nonces[0]+i));
    } finally {
      for(const name of ["report.json","summary.json","summary.md","controls.json","costs.json","transactions.jsonl"]){
        const f=path.join(output,name);if(fs.existsSync(f))fs.unlinkSync(f);
      }
      if(fs.existsSync(output))fs.rmdirSync(output);fs.rmdirSync(parent);
    }
  });
});
