// Execute a reviewed fresh 16-bit study manifest. Never replay an existing output.
process.env.SEPOLIA_MNEMONIC = '';
process.env.HARDHAT_NETWORK = 'sepolia';
require('ts-node/register/transpile-only');
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const hre = require('hardhat');
const { defaults, planSummary } = require('../tasks/studies/plan');
const { runStudy } = require('../tasks/studies/runner');
const { latestAttempts } = require('../tasks/studies/continuation');
const { loadAccounts } = require('../tasks/experiments/accounts');
const { deadline } = require('../tasks/lib/lifecycleTiming');
const { writeLifecycleJson } = require('../tasks/lib/lifecycleReportWrite');
const { safeError } = require('../tasks/lifecycle/errors');
const runFile = promisify(execFile);
const file = path.resolve(process.argv[2]);
const folder = path.dirname(file);
const hash = f => createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const manifest = JSON.parse(fs.readFileSync(file));
const lock = path.join(folder, 'launcher.lock');

function snapshot() {
  const files = [__filename, 'hardhat.config.ts', 'package-lock.json', 'tasks/benchmarkExperiments.ts',
    'tasks/experiments/accounts.ts', 'tasks/lifecycle/broadcast.ts', 'tasks/lifecycle/errors.ts',
    ...fs.readdirSync('tasks/studies').map(f => `tasks/studies/${f}`),
    ...fs.readdirSync('tasks/lib').filter(f => /lifecycle|cofheReadPolicy|decryptionPolling/.test(f)).map(f => `tasks/lib/${f}`),
    ...fs.readdirSync('contracts/studies').map(f => `contracts/studies/${f}`),
    'scripts/analysis/analyze-study-campaign.py', 'scripts/analysis/collect-operation-block-metadata.cjs'];
  return { files: Object.fromEntries(files.map(f => [path.relative(process.cwd(), f).replaceAll('\\', '/'), hash(f)])),
    polling: require('../tasks/lib/decryptionPolling.cjs').pollingProvenance() };
}

function save() {
  writeLifecycleJson(file, manifest);
  writeLifecycleJson(path.resolve('logs/study-active-campaign.json'), {
    pid: process.pid, status: manifest.status, startedAt: manifest.startedAt, manifest: file,
    currentStage: manifest.currentStage, report: manifest.currentReport,
    finishedAt: manifest.finishedAt, error: manifest.error,
  });
}

async function main() {
  if (manifest.kind !== 'full-16bit-concurrency-and-circuits' || manifest.chainId !== 11155111 ||
      manifest.status !== 'funded_ready' || manifest.stages.length !== 2)
    throw Error('A reviewed, funded and unstarted two-stage 16-bit manifest is required');
  for (const [i, stage] of manifest.stages.entries()) {
    const expected = { ...defaults, suite: ['circuits', 'concurrency'][i], widths: '16',
      seed: manifest.stages[0].args.seed, outputDir: stage.args.outputDir, live: false };
    if (stage.status !== 'planned' || JSON.stringify(stage.args) !== JSON.stringify(expected) ||
        JSON.stringify(stage.plan) !== JSON.stringify(planSummary(expected)) ||
        path.dirname(path.resolve(stage.args.outputDir)) !== folder || fs.existsSync(stage.args.outputDir))
      throw Error('Stage differs from the reviewed full matrix or output already exists');
  }
  fs.writeFileSync(lock, JSON.stringify({ pid: process.pid, at: new Date().toISOString() }), { flag: 'wx' });
  try {
    const frozen = snapshot();
    manifest.pid = process.pid; manifest.startedAt = new Date().toISOString();
    manifest.status = 'preflight'; manifest.sourceSnapshot = frozen; save();
    if ((await deadline(() => hre.ethers.provider.getNetwork(), 20000, 'chain identity')).chainId !== 11155111n)
      throw Error('Sepolia required');
    const accounts = loadAccounts(manifest.accountsFile, hre.ethers.provider);
    if (accounts.length !== 9) throw Error('Exactly nine saved study accounts required');
    manifest.launchPreflight = [];
    for (const account of accounts) {
      const read = (method, params) => deadline(() => hre.ethers.provider.send(method, params), 20000, 'launch account read');
      const latest = Number(BigInt(await read('eth_getTransactionCount', [account.address, 'latest'])));
      const pending = Number(BigInt(await read('eth_getTransactionCount', [account.address, 'pending'])));
      const balanceWei = BigInt(await read('eth_getBalance', [account.address, 'latest']));
      if (latest !== pending || balanceWei <= 0n) throw Error('Every study account must be funded with settled nonces');
      manifest.launchPreflight.push({ address: account.address, latest, pending, balanceWei: balanceWei.toString() });
    }
    save();
    for (const stage of manifest.stages) {
      if (JSON.stringify(snapshot()) !== JSON.stringify(frozen)) throw Error('Source or SDK changed between stages');
      manifest.status = 'running'; manifest.currentStage = `${stage.suite}/euint16`;
      manifest.currentReport = stage.report; stage.status = 'running'; stage.startedAt = new Date().toISOString(); save();
      const report = await runStudy({ ...stage.args, live: true }, hre);
      const latest = latestAttempts(report), requests = stage.suite === 'concurrency' ? 32 : 1;
      if (!report.executionComplete || latest.length !== (stage.plan.measuredTransactions + stage.plan.warmupTransactions) / requests ||
          latest.some(t => !['ok', 'capacity_rejected'].includes(t.status)))
        throw Error('Planned-slot coverage or completion validation failed');
      stage.status = 'finished'; stage.finishedAt = new Date().toISOString(); stage.rawSha256 = hash(stage.report);
      stage.allValid = report.complete;
      stage.counts = { measuredTrials: latest.filter(t => !t.warmup).length,
        validatedRequests: report.trials.filter(t => !t.warmup).flatMap(t => t.requests).filter(r => r.status === 'ok').length,
        capacityRejections: latest.filter(t => !t.warmup && t.status === 'capacity_rejected').length };
      save();
    }
    if (JSON.stringify(snapshot()) !== JSON.stringify(frozen)) throw Error('Source or SDK changed during measurement');
    manifest.status = 'analysis_running'; manifest.currentStage = 'canonical network audit and tables'; save();
    const python = path.resolve('.venv/Scripts/python.exe');
    const script = path.resolve('scripts/analysis/analyze-study-campaign.py');
    const output = await runFile(python, [script, folder, '--prepare-metadata'], { maxBuffer: 1024 * 1024 });
    fs.writeFileSync(path.join(folder, 'analysis-prepare.stdout.log'), output.stdout);
    await runFile(process.execPath, ['scripts/analysis/collect-operation-block-metadata.cjs', path.join(folder, 'network/input-plan.json')],
      { maxBuffer: 4 * 1024 * 1024 });
    const analysis = await runFile(python, [script, folder], { maxBuffer: 4 * 1024 * 1024 });
    fs.writeFileSync(path.join(folder, 'analysis.stdout.log'), analysis.stdout);
    manifest.status = manifest.stages.every(s => s.allValid) ? 'finished' : 'execution_complete_with_capacity_rejections';
    manifest.finishedAt = new Date().toISOString();
    manifest.networkReport = path.join(folder, 'network/network-report.md'); save();
  } catch (error) {
    manifest.status = 'failed'; manifest.error = safeError(error); manifest.finishedAt = new Date().toISOString();
    const stage = manifest.stages.find(s => s.status === 'running');
    if (stage) { stage.status = 'failed'; stage.error = manifest.error; }
    save(); throw error;
  } finally {
    fs.unlinkSync(lock);
  }
}

main().catch(error => { console.error(safeError(error)); process.exitCode = 1; });
